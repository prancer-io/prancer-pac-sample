import sys
import datetime
import time
import uuid
from prancer_template import gen_config_file

if __name__ == '__main__':
    if len(sys.argv) > 2 : 
       fname = sys.argv[1]
       # dt = datetime.datetime.now().strftime('%a %b %d %H:%M:%S UTC %Y')
       dt = datetime.datetime.now().strftime('%a, %d %b %Y %H:%M:%S')
       ep = int(time.time())
       uuid = str(uuid.uuid4()).replace('-', '')
       data = {
        'dt': dt,
        'epoch': ep,
        'id': uuid,
       }
       template = '%s.json' % sys.argv[2]
       status = gen_config_file(fname, template, data)
       exit(0 if status else 1)
    exit(1)
