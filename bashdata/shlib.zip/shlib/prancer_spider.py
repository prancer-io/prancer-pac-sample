import sys
import json

from prancer_template import gen_config_file

if __name__ == '__main__':
    if len(sys.argv) > 2 : 
       fname = sys.argv[1]
       data = {}
       template = '%s.json' % sys.argv[2]
       status = gen_config_file(fname, template, data)
       if len(sys.argv) > 3 : 
           data = None
           with open(fname) as f:
               data = json.loads(f.read())
           if data and 'allUrls' in data :
               data['allUrls'].append(sys.argv[3])
               with open(fname, 'w') as f:
                   f.write(json.dumps(data, indent=2))
       exit(0 if status else 1)
    exit(1)
